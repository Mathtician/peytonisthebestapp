package com.apps.team40.clickcounter;

public class TeamStats {

    //General Info
    private String TeamName;
    private int TeamNum;
    private String BotName;


    //Autonomous
    private boolean Landing = false;
    private boolean Claiming = false;
    private boolean Parking = false;
    private boolean Sampling = false;
    private int auto_Total = 0;



    //TeleOp
    private int Depot_Total = 0;
    private int Depot_Gold = 0;
    private int Depot_Silver = 0;
    private int Cargo_Bay_TOTAL = 0;
    private int Cargo_Bay_Gold = 0;
    private int Cargo_Bay_Silver = 0;
    private int Tele_Total_Points = 0;



    //End Game
    private int End_Depot_Gold = 0;
    private int End_Depot_Silver = 0;
    private int End_Cargo_Bay_Gold = 0;
    private int End_Cargo_Bay_Silver = 0;
    private boolean Latched = false;
    private boolean Parked_Partially = false;
    private boolean Parked_Completely = false;
    private int End_Total_Points = 0;

    public TeamStats(){}


    //General Sets and gets
    public String getTeamName() {
        return TeamName;
    }
    public void setTeamName(String teamName) {
        TeamName = teamName;
    }
    public int getTeamNum() {
        return TeamNum;
    }
    public void setTeamNum(int teamNum) {
        TeamNum = teamNum;
    }
    public String getBotName(){
        return getBotName();
    }
    public void setBotName(String botName) {
        BotName = botName;
    }



    // Autonomous
    public boolean isLanding() {
        return Landing;
    }
    public void setLanding(boolean landing) {
        Landing = landing;
    }
    public boolean isClaiming() {
        return Claiming;
    }
    public void setClaiming(boolean claiming) {
        Claiming = claiming;
    }
    public boolean isParking() {
        return Parking;
    }
    public void setParking(boolean parking) {
        Parking = parking;
    }
    public boolean isSampling() {
        return Sampling;
    }
    public void setSampling(boolean sampling) {
        Sampling = sampling;
    }
    public int getAuto_Total() {
        if (Landing){
            auto_Total += 30;
        }if (Claiming){
            auto_Total += 15;
        }if (Parking){
            auto_Total += 10;
        }if (Sampling){
            auto_Total += 25;
        }
        return auto_Total;
    }



    //Tele
    public int getDepot_Total() {
        Depot_Total = Depot_Silver+Depot_Gold;
        return Depot_Total;
    }
    public int getDepot_Gold() {
        return Depot_Gold;
    }
    public void setDepot_Gold(int depot_Gold) {
        Depot_Gold = depot_Gold;
    }
    public int getDepot_Silver() {
        return Depot_Silver;
    }
    public void setDepot_Silver(int depot_Silver) {
        Depot_Silver = depot_Silver;
    }
    public int getCargo_Bay_Gold() {
        return Cargo_Bay_Gold;
    }
    public void setCargo_Bay_Gold(int cargo_Bay_Gold) {
        Cargo_Bay_Gold = cargo_Bay_Gold;
    }
    public int getCargo_Bay_Silver() {
        return Cargo_Bay_Silver;
    }
    public void setCargo_Bay_Silver(int cargo_Bay_Silver) {
        Cargo_Bay_Silver = cargo_Bay_Silver;
    }
    public int getCargo_Bay_TOTAL() {
        Cargo_Bay_TOTAL = Cargo_Bay_Gold + Cargo_Bay_Silver;
        return Cargo_Bay_TOTAL;
    }
    public int getTele_Total_Points() {
        Tele_Total_Points = getDepot_Total() * 2 + getCargo_Bay_TOTAL() * 2;

        return Tele_Total_Points;
    }


    //end
    public int getEnd_Depot_Gold() {
        return End_Depot_Gold;
    }
    public void setEnd_Depot_Gold(int end_Depot_Gold) {
        End_Depot_Gold = end_Depot_Gold;
    }
    public int getEnd_Depot_Silver() {
        return End_Depot_Silver;
    }
    public void setEnd_Cargo_Bay_Silver(int end_Cargo_Bay_Silver) {
        End_Cargo_Bay_Silver = end_Cargo_Bay_Silver;
    }
    public int getEnd_Cargo_Bay_Gold() {
        return End_Cargo_Bay_Gold;
    }
    public void setEnd_Cargo_Bay_Gold(int end_Cargo_Bay_Gold) {
        End_Cargo_Bay_Gold = end_Cargo_Bay_Gold;
    }
    public int getEnd_Cargo_Bay_Silver() {
        return End_Cargo_Bay_Silver;
    }
    public void setLatched(boolean latched) {
        Latched = latched;
    }
    public boolean isLatched() {
        return Latched;
    }
    public void setParked_Partially(boolean parked_Partially) {
        Parked_Partially = parked_Partially;
    }
    public boolean isParked_Partially() {
        return Parked_Partially;
    }
    public void setParked_Completely(boolean parked_Completely) {
        Parked_Completely = parked_Completely;
    }
    public boolean isParked_Completely() {
        return Parked_Completely;
    }
    public int getEnd_Total_Points() {
        End_Total_Points += (End_Depot_Gold + End_Depot_Silver) * 2 + (End_Cargo_Bay_Gold + End_Cargo_Bay_Silver) * 5;

        if (Latched){
            End_Total_Points += 30;
        }else if (Parked_Completely){
            End_Total_Points += 25;
        }else if (Parked_Partially){
            End_Total_Points += 15;
        }

        return End_Total_Points;
    }
}
